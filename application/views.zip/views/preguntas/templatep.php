<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="<?php echo base_url(); ?>public/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
</head>
<body>
    <header></header>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-4">Logo</div>
            <div class="col-md-4">
                <div><h1>Nombre</h1></div>
                <div><small>slogan</small></div>
            </div>
            <div class="col-md-4"></div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <h1></h1>
            </div>
            <div class="col-md-6">
                respuesta
            </div>
        </div>
    </div>
</body>
</html>