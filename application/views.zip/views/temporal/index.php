

<div class="container">
    <div class="row">
        <div class="col-md-12">
        <div class="form-group">
            <div class="row">
                <div class="col-md-12">
                    <label for="">Aseguradora [La Ceiba]</label><br>
                    <label for="">Tipo Vehiculo [Agricola] </label><br>
                    <label for="">Prima Neta Anual [20%] </label><br>
                    <label for="">Tipo Seguros [Terceros]</label><br>
                    <input type="hidden" name="aseguradora"  id="aseguradora" >
                    <input type="hidden" name="tipovehiculo" id="tipovehiculo" >
                    <input type="hidden" name="primaneta"    id="primaneta" >
                    <input type="hidden" name="tiposeguro" value="<?php echo $tiposeguro; ?>"   id="tiposeguro" >

                </div>
                
            </div>
        </div>
        <section class ="ts" id="ts-1" >
        <br>
        <div class="alert alert-danger" role="alert">
            Existen Campos Vacios, Porfavor Verifique
        </div>
            <h3>Otros Cargos</h3>
            <span class="btn btn-info" id="add1">+</span>
            <span class="btn btn-success" id="sv1"><span class="glyphicon glyphicon-floppy-disk"></span></span>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Valor</th>
                        <th scope="col">Mas/Menos </th>
                        <th scope="col">Fijo/Calculado </th>
                        <th scope="col">Borrar</th>
                    </tr>
                </thead>

                
                <tbody id="tbody">
                    <tr class ="ot" id="ot-1">
                        <td>
                            <input type="text" name="otd-1" id="otd-1" class="form-control otd" >
                        </td>
                        <td>
                            <input type="text" name="otv-1" id="otv-1" class="form-control otv" >
                        </td>
                        <td>
                            <select name="otmm-1" id="otmm-1" class="form-control otmm">
                                <option value="+">+</option>
                                <option value="-">-</option>
                            </select>
                            
                        </td>
                        <td>
                            <input type="checkbox" name="otvf-1" id="otvf-1" class="otvf" >Valor Fijo <br>
                            <input type="checkbox" name="otc-1" id="otc-1" class="otc" >Calculado sobre prima Neta                            
                        </td>
                        <td><span class="btn btn-danger remove" remove="ot-1">-</span>    </td>
                    </tr>
                </tbody>
                </table>
        </section>
        <section class ="ts" id="ts-2">
        <br>
        <div class="alert alert-danger" role="alert">
            Existen Campos Vacios, Porfavor Verifique
        </div>
        <h3>Descuentos</h3>
            <span class="btn btn-info" id="add2">+</span>
            <span class="btn btn-success" id="sv2"><span class="glyphicon glyphicon-floppy-disk"></span></span>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Valor</th>
                        
                        <th scope="col">Propiedades</th>
                        <th scope="col">Borrar</th>
                    </tr>
                </thead>

                
                <tbody id="tbody2">
                    <tr class ="ot" id="d-1">
                        <td>
                            <input type="text" name="dd-1" id="dd-1" class="form-control dd" >
                        </td>
                        <td>
                            <input type="text" name="dv-1" id="dv-1" class="form-control dv" >
                        </td>

                        <td>
                            <input type="checkbox" name="dvf-1" id="otvf-1" class="dvf" >Valor Fijo <br>
                            <input type="checkbox" name="dc-1" id="otc-1" class="dc" >Calculado sobre prima Neta                            
                        </td>
                        <td><span class="btn btn-danger remove" remove="d-1">-</span>    </td>
                    </tr>
                </tbody>
                </table>

        </section>
        <section class ="ts" id="ts-3">
        <br>
        <div class="alert alert-danger" role="alert">
            Existen Campos Vacios, Porfavor Verifique
        </div>
        <h3>Seccion IAB</h3>
            <span class="btn btn-info" id="add3">+</span>
            <span class="btn btn-success" id="sv3"><span class="glyphicon glyphicon-floppy-disk"></span></span>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Valor</th>
                    </tr>
                </thead>
                <tbody id="tbody3">
                    <tr class ="iab" id="iab-1">
                        <td>
                            <input type="text" name="iab-1" id="iabd-1" class="form-control iabd" >
                        </td>
                        <td>
                            <input type="text" name="iab-1" id="iabv-1" class="form-control iabv" >
                        </td>
                        <td><span class="btn btn-danger remove" remove="iab-1">-</span>    </td>
                    </tr>
                </tbody>
                </table>
        </section>

        <section class ="ts" id="ts-4">
        <br>
        <div class="alert alert-danger" role="alert">
            Existen Campos Vacios, Porfavor Verifique
        </div>
        <h3>Seccion IIAB</h3>
            <span class="btn btn-info" id="add4">+</span>
            <span class="btn btn-success" id="sv4"><span class="glyphicon glyphicon-floppy-disk"></span></span>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Valor</th>
                    </tr>
                </thead>

                
                <tbody id="tbody4">
                    <tr class ="iiab" id="iiab-1">
                        <td>
                            <input type="text" name="iiabd-1" id="iiabd-1" class="form-control iiabd" >
                        </td>
                        <td>
                            <input type="text" name="iiabd-1" id="iiabv-1" class="form-control iiabv" >
                        </td>
                        <td><span class="btn btn-danger remove" remove="iiab-1">-</span>    </td>
                    </tr>
                </tbody>
                </table>
        </section>
        <section class ="ts" id="ts-5">
        <br>
        <div class="alert alert-danger" role="alert">
            Existen Campos Vacios, Porfavor Verifique
        </div>
        <h3>Seccion IIIAB</h3>
            <span class="btn btn-info" id="add5">+</span>
            <span class="btn btn-success" id="sv5"><span class="glyphicon glyphicon-floppy-disk"></span></span>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Valor</th>
                    </tr>
                </thead>                
                <tbody id="tbody5">
                    <tr class ="iiiab" id="iiiab-1">
                        <td>
                            <input type="text" name="otd-1" id="iiiabv-1" class="form-control iiiabd" >
                        </td>
                        <td>
                            <input type="text" name="otv-1" id="iiiabv-1" class="form-control iiiabv" >
                        </td>
                        <td><span class="btn btn-danger remove" remove="iiiab-1">-</span>    </td>
                    </tr>
                </tbody>
                </table>
        </section>
        <section class ="ts" id="ts-6">
        <br>
        <div class="alert alert-danger" role="alert">
            Existen Campos Vacios, Porfavor Verifique
        </div>
        <h3>Coberturas</h3>
            <span class="btn btn-info" id="add6">+</span>
            <span class="btn btn-success" id="sv6"><span class="glyphicon glyphicon-floppy-disk"></span></span>
            <table class="table">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">Descripcion</th>
                        <th scope="col">Valor</th>
                    </tr>
                </thead>

                
                <tbody id="tbody6">
                    <tr class ="ot" id="c-1">
                        <td>
                            <input type="text" name="c-1" id="cd-1" class="form-control cd" >
                        </td>
                        <td>
                            <input type="text" name="otv-1" id="cv-1" class="form-control cv" >
                        </td>
                        <td><span class="btn btn-danger remove" remove="c-1">-</span>    </td>
                    </tr>
                </tbody>
                </table>
        </section>

        </div>
    </div>
</div>


    <script src="http://localhost/segurosautomovil/assets/grocery_crud/js/jquery-1.11.1.min.js"></script>
    <script src="http://localhost/segurosautomovil/assets/grocery_crud/js/common/list.js"></script>
    
    <script src="http://localhost/segurosautomovil/assets/grocery_crud/js/jquery_plugins/jquery.fancybox-1.3.4.js"></script>
    <script src="http://localhost/segurosautomovil/assets/grocery_crud/js/jquery_plugins/jquery.easing-1.3.pack.js"></script>


<script>
(function(){
    $(document).ready(function(){
        $.noConflict();
        adTr();
        adTr2();
        adTr3();
        adTr4();
        adTr5();
        adTr6();
        remove();
        removeError();
        // $('.alert').alert('close');
        $("#sv1").click(function(){
            send= validateM(["otd","otv"]);
            if(send == true){
                container =[];
                container2 =[];
                container3 =[];
                container4 =[];
                container5 =[];
                format={
                    "decripcion":"",
                    "valor":"",
                    "masmenos":"",
                    "valorfijo":"",
                    "cspn":"",
                    "operacion":"otroscargos"    
                }
                cd  = $('.otd');
                cv  = $('.otv');
                cmm = $('.otmm');
                cvf = $('.otvf')
                cc  = $('.otc');
                ln  = cd.length;
                for (i=0;i<ln;i++){
                    id = "#"+$(cmm[i]).attr("id");
                    id2 = "#"+$(cvf[i]).attr("id");
                    container[i]=$(cd[i]).val();
                    container2[i]=$(cv[i]).val();
                    container3[i]=$(id+" option:selected").val();
                    container4[i]=$(cvf[i]).is(":checked");
                    container5[i]=$(cc[i]).is(":checked");
                }
                info={
                    "descripcion":container,
                    "valor":container2,
                    "masmenos":container3,
                    "valorfijo":container4,
                    "cspn":container5,
                    "operacion":"otroscargos",
                    "tiposeguro":$('#tiposeguro').val()
                }
                sendPost(info,"")

                // ln = cd.length;
                // for(i =0;i<ln;i++){
                //     format.descripcion = $(cd[i]).val();
                //     format.valor = $(cv[i]).val();
                //     id = "#"+$(cmm[i]).attr("id");
                //     format.cspn = ($(cc[i]).prop("checked")==true)?"si":"no";
                //     format.valorfijo = ($(cvf[i]).prop("checked")==true)?"si":"no";
                //     format.masmenos = $(id+" option:selected").val();
                //     container[i] = format;

                // }
                
                console.log(container);
            }
        });
        $("#sv2").click(function(){
            send= validateM(["dd","dv"]);
            if(send == true){
                container =[];
                format={
                    "decripcion":"",
                    "valor":"",
                    "masmenos":"",
                    "valorfijo":"",
                    "cspn":"",
                    "operacion":"descuentos" 
                }
                cd = $('.dd');
                cv = $('.dv');
                cmm = $('.dmm');
                cvf = $('dc');
                ln = cd.length;
                for(i =0;i<ln;i++){
                    format.descripcion = $(cd[i]).val();
                    format.valor = $(cv[i]).val();
                    format.masmenos = "-";
                    format.cspn = ($(cc[i]).prop("checked")==true)?"si":"no";
                    format.valorfijo = ($(cvf[i]).prop("checked")==true)?"si":"no";
                    container[i] = format;
                }
                console.log(container);
            }

        });
        $("#sv3").click(function(){
            send= validateM(["iabd","iabv"]);
            if(send == true){
                container =[];
                format={
                    "decripcion":"",
                    "valor":"",
                    "operacion":"iab" 
                }
                cd = $('.iabd');
                cv = $('.iabv');
                ln = cd.length;
                for(i =0;i<ln;i++){
                    format.descripcion = $(cd[i]).val();
                    format.valor = $(cv[i]).val();
                    container[i] = format;
                }
                console.log(container);
            }
        });
        $("#sv4").click(function(){
            send= validateM(["iiabd","iiabv"]);
            if(send == true){
                container =[];
                format={
                    "decripcion":"",
                    "valor":"",
                    "operacion":"iiab" 
                }
                cd = $('.iiabd');
                cv = $('.iiabv');
                ln = cd.length;
                for(i =0;i<ln;i++){
                    format.descripcion = $(cd[i]).val();
                    format.valor = $(cv[i]).val();
                    container[i] = format;
                }
                console.log(container);
            }
            
            console.log(container);
        });
        $("#sv5").click(function(){
            send= validateM(["iiiabd","iiiabv"]);
            if(send == true){
                container =[];
                format={
                    "decripcion":"",
                    "valor":"",
                    "operacion":"iiab" 
                }
                cd = $('.iiiabd');
                cv = $('.iiiabv');
                ln = cd.length;
                for(i =0;i<ln;i++){
                    format.descripcion = $(cd[i]).val();
                    format.valor = $(cv[i]).val();
                    container[i] = format;
                }
                console.log(container);
            }
            
            console.log(container);
        });
        $("#sv6").click(function(){
            send= validateM(["cd","cv"]);
            if(send == true){
                container =[];
                container2 =[] 
                format={
                    "decripcion":"",
                    "valor":"",
                    "operacion":"cobertura" 
                }
                
                cd = $('.cd');
                cv = $('.cv');
                ln = cd.length;
                for (i=0;i<ln;i++){
                    container[i]=$(cd[i]).val();
                    container2[i]=$(cv[i]).val();
                }
                info={
                    "descripcion":container,
                    "valor":container2,
                    "operacion":"coberturas"
                }
                sendPost(info,"")
                console.log(container);
            }
            
            console.log(container);
        });
        $('.alert-danger').hover(function(){
            $(this).hide("slow");
        });

    });
})();
adTr = function(){
    $('#add1').click(function(){
        n = $('#tbody').children().length +1;
        str = "";
        str+="<tr class ='ot' id='ot-"+n+"'>";
        str+="    <td>";
        str+=addTx(n,"otd","text");
        str+="    </td>";
        str+="    <td>";
        str+=addTx(n,"otv","text");
        str+="    </td>";
        str+="    <td>";
        str+=addSelect(n,"otmm");
        str+="    </td>";
        str+="    <td>";
        str+=addTx(n,"otvf","checkbox","Valor Fijo")+"<br>";
        str+=addTx(n,"otc","checkbox", "Calculado Sobre Prima Neta");
        str+="    </td>";
        str+="    <td>";
        str+=addRemove(n,"ot");
        str+="    </td>";
        str+="</tr>";
        $('#tbody').append(str);
        remove();
        removeError();
    });

}

adTr2 = function(){
    $('#add2').click(function(){
        n = $('#tbody2').children().length +1;
        str = "";
        str+="<tr class ='d' id='d-"+n+"'>";
        str+="    <td>";
        str+=addTx(n,"dd","text");
        str+="    </td>";
        str+="    <td>";
        str+=addTx(n,"dv","text");
        str+="    </td>";
        str+="    <td>";
        str+=addTx(n,"dvf","checkbox","Valor Fijo")+"<br>";
        str+=addTx(n,"otc","checkbox", "Calculado Sobre Prima Neta");
        str+="    </td>";
        str+="    <td>";
        str+=addRemove(n,"d");
        str+="    </td>";
        str+="</tr>";
        $('#tbody2').append(str);
        remove();
        removeError();
    });

}
adTr3 = function(){
    $('#add3').click(function(){
        n = $('#tbody3').children().length +1;
        str = "";
        str+="<tr class ='iab' id='iab-"+n+"'>";
        str+="    <td>";
        str+=addTx(n,"iabd","text");
        str+="    </td>";
        str+="    <td>";
        str+=addTx(n,"iabv","text");
        str+="    </td>";
        str+="    <td>";
        str+=addRemove(n,"iab");
        str+="    </td>";
        str+="</tr>";
        $('#tbody3').append(str);
        remove();
        removeError();
    });

}
adTr4 = function(){
    $('#add4').click(function(){
        n = $('#tbody4').children().length +1;
        str = "";
        str+="<tr class ='iiab' id='iiab-"+n+"'>";
        str+="    <td>";
        str+=addTx(n,"iiabd","text");
        str+="    </td>";
        str+="    <td>";
        str+=addTx(n,"iiabv","text");
        str+="    </td>";
        str+="    <td>";
        str+=addRemove(n,"iiab");
        str+="    </td>";
        str+="</tr>";
        $('#tbody4').append(str);
        remove();
    });

}
adTr5 = function(){
    $('#add5').click(function(){
        n = $('#tbody5').children().length +1;
        str = "";
        str+="<tr class ='iiiab' id='iiiab-"+n+"'>";
        str+="    <td>";
        str+=addTx(n,"iiiabd","text");
        str+="    </td>";
        str+="    <td>";
        str+=addTx(n,"iiiabv","text");
        str+="    </td>";
        str+="    <td>";
        str+=addRemove(n,"iiiab");
        str+="    </td>";
        str+="</tr>";
        $('#tbody5').append(str);
        remove();
        removeError();
    });

}
adTr6 = function(){
    $('#add6').click(function(){
        n = $('#tbody5').children().length +1;
        str = "";
        str+="<tr class ='c' id='c-"+n+"'>";
        str+="    <td>";
        str+=addTx(n,"cd","text");
        str+="    </td>";
        str+="    <td>";
        str+=addTx(n,"cv","text");
        str+="    </td>";
        str+="    <td>";
        str+=addRemove(n,"c");
        str+="    </td>";
        str+="</tr>";
        $('#tbody6').append(str);
        remove();
        removeError();
    });

}

addSelect = function(n,nam){
    str = "<select name='"+nam+"-"+n+"' class='form-control "+nam + "' id='"+nam+"-"+n+"'>";
    str+= "<option value='+'>+</option>";
    str+= "<option value='-'>-</option>";
                                
    str+= "</select>";
    
    return str;

}
addTx = function(n,nam,type,lbl=""){
    if(type !="checkbox"){
        str = "<input type='"+type+"' name='"+nam+"-"+n+"' class='form-control "+nam+"' id='"+nam+"-"+n+"'>"+" "+lbl+ " " ;
    }
    else{
        str = "<input type='"+type+"' name='"+nam+"-"+n+"' class='"+nam+"' id='"+nam+"-"+n+"'>"+" "+lbl+ " " ;
    }
    
    return str;
}
addRemove = function(n,nam){
    str = "<span  class='btn btn-danger remove' remove ='"+nam+"-"+n+"'>-</span>";
    return str;
}
remove = function(){
    $('.remove').click(function(){
        id = "#"+$(this).attr('remove');
        $(id).remove();
    });

}
validateField = function(name){
    str = "."+name;
    a = $(str);
    isOk = true;
    for(i=0;i<a.length;i++){
        temp =$(a[i]).val();
        if((temp.length<1)){
            isOk =false;
            $(a[i]).addClass('error');
            id = "#"+  $(a[i]).parent().parent().parent().parent().parent().attr("id");
            $(id+' .alert-danger').show("slow")

        }
    }
    return isOk;
}
validateM =function(arr){
    for(j=0;j<arr.length;j++){
        temp = validateField(arr[j]);
    }
    return temp;
}
removeError = function(){
    $('.form-control').keypress(function(){
        if(($(this).val().length > 0)&& ($(this).val()!="") && ($(this).val()!=" ") ){
            $(this).removeClass("error")
        }
    });
}
sendPost = function(info,idResponse){
    jQuery.post( "<?php echo base_url("temporal/insanddelete"); ?>", info , function(data) {
       alert(data);
    });
    
}



</script>
<style>
.ts{
    border: 1px dotted blue;
    padding: 0px 15px;
    margin-top:10px;
    background-color:#fff;
}
.error{
    border-color:red;
}
.alert-danger{
    display:none;
}

</style>