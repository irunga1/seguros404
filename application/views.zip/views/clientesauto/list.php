<h1>
   Tus Posibles Aseguradoras
</h1>
<br>
<div class="continer-fluid">
    <div class="row item">
        <div class="col-md-3">
            <img class="listimg" src="<?php echo base_url("public/img/aseguradoras/logo2.svg") ?>" alt="">
        </div>
        <div class="col-md-6">
            <h3>Aseguradora General</h3>
            <strog>Tasa de Interes 10%</strong>
            <a href="#">Visita el Sitio</a>
            

        </div>
        <div class="col-md-3">
            <small>Comaparalo</small>
            <input type="checkbox" name="" id="as-1" class="form-control compare" value="1"> 
            <a class="btn btn-warning btn-lg">Warning</a>
        </div>
    </div>
</div>


<style>
div.row,div.col-md-3,div.col-md-6{
    /* border: 1px solid gray; */
    min-height: 125px;
}
.listimg{
    max-width:150px;
    width:100%
}
.info{
    width:50%;
    display:inline-block;
}
.col-md-3{
    text-align:center;
}
.item{
    border-bottom:1px dotted silver;
}
</style>