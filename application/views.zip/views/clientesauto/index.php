<h1>
    Formulario Cotizacion
</h1>
<form action="" method="post">
<div class="form-group">
    <div class="row">
        <div class="col-md-2"><label for="">Nombre <span class="asterisco">*</span></label></div>  
        <div class="col-md-10">
            <input required type="text" name="Nombre" maxlength="145" class="form-control" id="Nombre" placeholder="Ingrese Nombre">
        </div>
    </div>
    
</div>
<div class="form-group">
    <div class="row">
    <div class="col-md-2"><label for="">Email <span class="asterisco">*</span></label></div> 
    <div class="col-md-10">
        <input required type="email" name="Email" class="form-control" id="Email" placeholder="Ingrese Correo" >
    </div>
    </div>
</div>
<div class="form-group">
    <div class="row">
    <div class="col-md-2"><label for="">Marca <span class="asterisco">*</span></label></div> 
    <div class="col-md-10">
        <select required name="Marca" id="make" class="form-control">        
            <option class="vehicle-search" value="Audi">Audi</option>
            <option class="vehicle-search" value="BMW">BMW</option>
            <option class="vehicle-search" value="Chevrolet">Chevrolet</option>
            <option class="vehicle-search" value="Daewoo">Daewoo</option>
            <option class="vehicle-search" value="Ford">Ford</option>
            <option class="vehicle-search" value="Honda">Honda</option>
            <option class="vehicle-search" value="Hyundai">Hyundai</option>
            <option class="vehicle-search" value="Isuzu">Isuzu</option>
            <option class="vehicle-search" value="Kia">Kia</option>
            <option class="vehicle-search" value="Lexus">Lexus</option>
            <option class="vehicle-search" value="Mazda">Mazda</option>
            <option class="vehicle-search" value="Mitsubishi">Mitsubishi</option>
            <option class="vehicle-search" value="Nissan">Nissan</option>
            <option class="vehicle-search" value="Peugeot">Peugeot</option>
            <option class="vehicle-search" value="Subaru">Subaru</option>
            <option class="vehicle-search" value="Suzuki">Suzuki</option>
            <option class="vehicle-search" value="Toyota">Toyota</option>
            <option class="vehicle-search" value="Volkswagen">Volkswagen</option>
            <option class="vehicle-search" value="Volvo">Volvo</option>
        </select>
    </div>
    </div>

    
</div>
<div class="form-group">
    <div class="row">
    <div class="col-md-2"><label for="">Linea <span class="asterisco">*</span></label></div> 
    <div class="col-md-10">
        <input required type="text" name="Linea" maxlength="50" class="form-control" id="Linea" placeholder="Ingrese Linea">
    </div>
    </div>
</div>

<div class="form-group">
    <div class="row">
        <div class="col-md-2"><label for="">Modelo <span class="asterisco">*</span></label></div> 
        <div class="col-md-10">
            <input type="text" name="Marca" class="form-control" id="Modelo" placeholder="Ingrese Modelo">
        </div>
    </div>

</div>
<div class="form-group">
    <div class="row">
        <div class="col-md-2"><label for="">Valor <span class="asterisco">*</span> </label></div> 
        <div class="col-md-10">
        <input required type="text" name="Valor" maxlength="4" class="form-control" id="Valor" placeholder="Ingrese Valor">
        </div> 
    </div> 
</div>
<div class="form-group">
<div class="row">
    <div class="col-md-2"><label for="">Captcha <span class="asterisco">*</span></label></div> 
    <div class="col-md-2">
        <?php         
            $captcha = $this->captcha->generateString(); 
            $this->session->set_userdata(["captcha"=> $captcha]);
            $this->captcha->generateImage();
        ?>    
    </div>
    <div class="col-md-8">
        <input required type="text" name="Valor" maxlength="8" class="form-control" id="Valor" placeholder="Ingrese el valor de la  imagen">
    </div>
</div>
</div>
<label class="radio-inline">
    <input type="radio" name="optradio" checked>Para Terceros 
</label>
<i class="glyphicon glyphicon-zoom-in"></i>
<label class="radio-inline">
    <input type="radio" name="optradio">Completo 
</label>
<i class="glyphicon glyphicon-zoom-in"></i>
<button class="btn btn-info col-md-12" id="enviar">Enviar</button>
</form>

<style>
.asterisco{
    color:red;
}

</style>

<script>
    (function(){
        $(document).ready(function(){
            valor();
            onlyLetters();
        });

    })()
    valor = function(){
        $('#Valor').mask('000,000,000,000,000.00', {reverse: true});
        $('#Modelo').mask('0000', {reverse: true});

    }
    onlyLetters = function(){
        $("#Nombre , #Linea ").keydown(function(event){
            var inputValue = event.which;
            // allow letters and whitespaces only.
            if(!(inputValue >= 65 && inputValue <= 120) && (inputValue != 32 && inputValue != 0)) { 
                event.preventDefault(); 
            }
        });
    }

</script>
