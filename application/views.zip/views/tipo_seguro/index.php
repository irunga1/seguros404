<?php foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php     
    echo $output;
?>
<?php foreach($js_files as $file): ?>
    <script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<script>
(function(){
    $(document).ready(function(){
        appendBtn();
    });
})();
appendBtn = function(){
    url = window.location.href;
    vec = url.split("/");
    size = vec.length;
    last = vec[size-1];
    link = "<a href ='" + base_url + "tiposeguro/config/" +last+ "' type='button' value='Volver a la lista' class='ui-input-button back-to-list ui-button ui-widget ui-state-default ui-corner-all mbtn' >Ir a Configuracion</a>";
    $('.form-button-box').append(link);
}
appendBtn2 = function(){
    url = window.location.href;
    vec = url.split("/");
    size = vec.length;
    last = vec[size-1];
}
</script>
<style>
.mbtn{
    padding:4px;
}
</style>